Keep GingerBooks backup files (.json) here.
Set the app auto-backup file to this folder: Settings & backup > Choose auto-backup file.
