Save bank statements (.xlsx or .csv) downloaded from net banking here, then import them in GingerBooks > Bank statement.
Sample-bank-statement.csv shows the expected format.
