' GingerBooks: puts a GingerBooks shortcut with the MiCAE icon on the Desktop.
' Double-click this file once. Safe to run again (it just refreshes the shortcut).
Option Explicit
Dim sh, fso, here, desk, lnk
Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
here = fso.GetParentFolderName(WScript.ScriptFullName)
If Not fso.FileExists(here & "\GingerBooks.html") Then
  MsgBox "GingerBooks.html was not found next to this file." & vbCrLf & "Keep this file inside the GingerCan folder and try again.", 48, "GingerBooks"
  WScript.Quit
End If
desk = sh.SpecialFolders("Desktop")
Set lnk = sh.CreateShortcut(desk & "\GingerBooks.lnk")
lnk.TargetPath = here & "\GingerBooks.html"
lnk.WorkingDirectory = here
If fso.FileExists(here & "\micae.ico") Then lnk.IconLocation = here & "\micae.ico,0"
lnk.Description = "GingerBooks - open the books"
lnk.Save
MsgBox "Done. A GingerBooks shortcut with the MiCAE icon is now on your Desktop.", 64, "GingerBooks"
