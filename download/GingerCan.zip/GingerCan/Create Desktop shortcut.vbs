' GingerBooks: puts a "GingerBooks" shortcut with the MiCAE icon on the Desktop
' and gives the GingerCan folder the MiCAE icon.
' Double-click once. Safe to run again: it replaces the same shortcut, never duplicates.
Option Explicit
Dim sh, fso, here, desk, ico, ini, f
Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
here = fso.GetParentFolderName(WScript.ScriptFullName)
If Not fso.FileExists(here & "\GingerBooks.html") Then
  MsgBox "GingerBooks.html was not found next to this file." & vbCrLf & "Keep this file inside the GingerCan folder and try again.", 48, "GingerBooks"
  WScript.Quit
End If
ico = here & "\micae.ico"
desk = sh.SpecialFolders("Desktop")

Sub MakeLink(path)
  Dim lnk
  Set lnk = sh.CreateShortcut(path)
  lnk.TargetPath = here & "\GingerBooks.html"
  lnk.WorkingDirectory = here
  If fso.FileExists(ico) Then lnk.IconLocation = ico & ",0"
  lnk.Description = "GingerBooks - open the books"
  lnk.Save
End Sub

MakeLink desk & "\GingerBooks.lnk"
If fso.FileExists(here & "\GingerBooks.lnk") Then fso.DeleteFile here & "\GingerBooks.lnk", True

' Folder icon (desktop.ini, hidden + system; folder marked read-only so Windows uses it)
If fso.FileExists(ico) Then
  On Error Resume Next
  ini = here & "\desktop.ini"
  If fso.FileExists(ini) Then fso.GetFile(ini).Attributes = 0
  Set f = fso.CreateTextFile(ini, True)
  f.WriteLine "[.ShellClassInfo]"
  f.WriteLine "IconResource=micae.ico,0"
  f.WriteLine "IconFile=micae.ico"
  f.WriteLine "IconIndex=0"
  f.Close
  fso.GetFile(ini).Attributes = 2 + 4
  fso.GetFolder(here).Attributes = fso.GetFolder(here).Attributes Or 1
  On Error GoTo 0
End If

MsgBox "Done." & vbCrLf & vbCrLf & _
  "- A GingerBooks shortcut with the MiCAE icon is on your Desktop." & vbCrLf & _
  "- The GingerCan folder now shows the MiCAE icon (it may take a minute, or press F5 in File Explorer).", 64, "GingerBooks"
