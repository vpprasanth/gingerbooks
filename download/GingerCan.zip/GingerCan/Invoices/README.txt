Save invoice and credit note PDFs here (Print > Save as PDF).
